package chat;

import javax.swing.SwingUtilities;

public class ServerMain {

	public static void main(String[] args) {
		SwingUtilities.invokeLater(new Runnable() {
			public void run() {
				ServerController sc = new ServerController("127.0.0.1", 3450);
			}
		});
	}
}
