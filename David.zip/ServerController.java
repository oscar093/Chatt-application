package chat;

import java.awt.event.ActionEvent;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;

public class ServerController implements Runnable {
	
	private ServerUI sui = new ServerUI(this);
	
	private Thread server;
	private ServerSocket serverSocket;
	private String ip;
	private int port;
	private ArrayList<String> users = new ArrayList();
	
	public ServerController(String ip, int port) {
		this.ip = ip;
		this.port = port;
	}
	
	public void startServer(ActionEvent evt) throws IOException {
		this.server = new Thread(this);
		this.serverSocket = new ServerSocket(this.port);
		this.server.start();
	}

	@Override
	public void run() {
		while(true) {
			try {
				Socket socket = serverSocket.accept();
				new ClientHandler(socket).start();
			} catch(IOException e) {}
		}
	}
	
	private class ClientHandler extends Thread {
		private Socket socket;
		
		public ClientHandler(Socket socket) {
			this.socket = socket;
		}
		
		public void run() {
			try {
				ObjectInputStream ois = new ObjectInputStream(socket.getInputStream());
				ObjectOutputStream oos = new ObjectOutputStream(socket.getOutputStream());
				while(true) {
					Object obj = ois.readObject();
					if(obj instanceof Connect) {
						String username;
						username = ((Connect) obj).getUsername();
						users.add(username);
						sui.ta_chat.append(username + " is now connected");
					}
				}
			} catch(IOException | ClassNotFoundException e) {}
			try {
				socket.close();
			} catch(IOException e) {}
		}
	}
}